package farm.core.farmgrid;

import farm.core.UnableToInteractException;
import farm.core.farmgrid.managers.*;
import farm.core.farmgrid.managers.itemmanager.*;
import farm.inventory.product.*;

import java.util.List;

/**
 * REFACTORED FarmGrid Class representing a grid-based farm system that handles plants or animal.
 * This class delegates management of display, interactions and farm items to specialised managers.
 *
 * Class Invariant:
 * @invariant  must remain either "animal" or "plant" after initialisation.
 * @invariant  position must be either an empty ground or a valid item ("animal" or "plant")
 */
public class FarmGrid implements Grid {
    // Manages farm items.
    private final FarmItemManager itemManager;
    // Handles interactions between user and farm interface.
    private final FarmInteractionManager interactionManager;
    // Manages display of farm grid.
    private final FarmDisplayManager displayManager;
    private String farmType;
    private List<List<String>> farmState;

    /**
     * Constructor for FarmGrid.
     * @param rows number of rows in the farm grid.
     * @param columns number of columns in the farm grid.
     * @param farmType the type of farm ("animal" or "plant").
     * @throws IllegalArgumentException if farmType is not valid ("animal" or "plant").
     *
     * @requires number of rows and columns must be greater than 0.
     * @requires farmType must be either "animal" or "plant".
     * @ensures appropriate FarmItemManager (AnimalFarmItemManager or PlantFarmItemManager) is
     * initialised depending on the farmType.
     * @ensures farm grid is correctly initialised with specified rows and columns.
     */

    public FarmGrid(int rows, int columns, String farmType) throws IllegalArgumentException {
        // design Choice: user must choose which farm type instead of assumed "plant"
        if (farmType.equals("animal")) {
            this.itemManager = new AnimalFarmItemManager(rows, columns);
        } else if (farmType.equals("plant")) {
            this.itemManager = new PlantFarmItemManager(rows, columns);
        } else {
            throw new IllegalArgumentException("Invalid farm type: " + farmType);
        }

        interactionManager = new FarmInteractionManager(itemManager);
        displayManager = new FarmDisplayManager(itemManager.getFarmState(), rows, columns);
    }

    /**
     * Places an item on the farm at specified coordinates (row and column).
     * @param row row coordinate
     * @param column the column coordinate
     * @param symbol character representing the item to be placed
     * @return true if item was placed successfully, false otherwise.
     *
     * @requires row and column are valid coordinates within the grid.
     * @requires symbol represents valid animal or plant depending on farmType.
     * @ensures correct item is placed at specified coordinate.
     */
    @Override
    public boolean place(int row, int column, char symbol) {
        // Delegate to FarmItemManager
        return itemManager.place(row, column, symbol);
    }

    /**
     * Harvests the item at specified coordinates.
     * @param row row coordinate
     * @param column column coordinate
     * @return product harvested from the item at coordinate.
     * @throws UnableToInteractException if item cannot be harvested (e.g. not ready or does not
     * exist)
     *
     * @requires row and column are valid coordinates within the grid.
     * @requires item at coordinates is ready to be harvested.
     * @ensures item is harvest and its state is updated correctly (animal collected or plant
     * resets)
     */


    @Override
    public Product harvest(int row, int column) throws UnableToInteractException {
        // Delegate to FarmItemManager
        return itemManager.harvest(row, column);
    }

    /**
     * Process an interaction command on the farm.
     *
     * @param command the interaction to perform
     * @param row the row coordinate
     * @param column the column coordinate
     * @return true if interaction was successful, false otherwise.
     * @throws UnableToInteractException if interaction cannot be performed (e.g. invalid command
     * or position).
     *
     * @requires command is a valid interaction (e.g. feed, remove, or end-day).
     * @requires row and column are valid coordinates within the grid.
     * @ensures corresponding interaction is successfully executed on item at coordinates.
     */
    @Override
    public boolean interact(String command, int row, int column) throws UnableToInteractException {
        // Delegate to FarmInteractionManager for handling commands
        return interactionManager.interact(command, row, column);
    }

    /**
     * Generates and displays current visual representation of farm grid.
     * @return String representing current state of farm grid.
     *
     */
    @Override
    public String farmDisplay() {
        // Delegate to display manager for generating the farm's visual representation
        return displayManager.farmDisplay();
    }

    /**
     * Retrieves farm's state which shows the status of each item in the grid.
     * @return a list of lists where each inner list contains item and its details.
     */
    @Override
    public List<List<String>> getStats() {
        return itemManager.getFarmState();
    }

    /**
     * Getter method for number of rows.
     * @return number of rows in farm grid.
     */
    @Override
    public int getRows() {
        return itemManager.getRows();
    }

    /**
     * Getter method for number of columns.
     * @return number of columns in farm grid.
     */
    @Override
    public int getColumns() {
        return itemManager.getColumns();
    }

    /**
     * Getter method for farm type.
     * @return the farm's type.
     */
    public String getFarmType() {
        return itemManager.getFarmType();
    }


    /**
     * Getter methods for symbol from item
     * @param row row coordinate
     * @param column column coordinate
     * @return symbol from item
     */
    public char getSymbolAt(int row, int column) {
        return itemManager.getSymbolAt(row, column);  // Delegates to the item manager
    }



}

