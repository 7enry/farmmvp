package farm.core.farmgrid.managers;

import farm.core.UnableToInteractException;
import farm.core.farmgrid.managers.itemmanager.AnimalFarmItemManager;

import java.util.*;

/**
 * Class that handles certain interactions with the farm items.
 * This includes feeding animals, removing items, or ending the day.
 * Class Invariant:
 * @invariant itemManager must always be a valid instance of FarmItemManager or its subclasses.
 */
public class FarmInteractionManager {
    // delegates item-specific tasks to FarmItemManager
    private final FarmItemManager itemManager;

    /**
     * Constructor for FarmInteractionManager.
     * @param itemManager item manager responsible for farm items.
     *
     * @requires itemManager is not null.
     * @ensures itemManager is instantiated in this class.
     */
    public FarmInteractionManager(FarmItemManager itemManager) {
        if (itemManager == null) {
            throw new IllegalArgumentException("itemManager cannot be null");
        }
        this.itemManager = itemManager;
    }

    /**
     * Interacts with a farm item at specified coordinates, based on command given.
     * @param command interaction command (feed, remove, end-day)
     * @param row row coordinate
     * @param column column coordinate
     * @return true if interaction was successful, false otherwise.
     * @throws UnableToInteractException if unsuccessful execution - command is unknown, etc.
     *
     * @requires row and column are valid grid coordinates within farm bounds.
     * @requires command to be either feed, remove or end-day for this method.
     * @ensures interaction is executed successfully, farmState is updated accordingly.
     */
    public boolean interact(String command, int row, int column) throws UnableToInteractException {


        return switch (command.toLowerCase()) {
            case "feed" -> feedAnimal(row, column);
            case "remove" -> removeItem(row, column);
            case "end-day" -> {
                itemManager.endDay();
                yield true; // return true
            }
            default -> throw new UnableToInteractException("Unknown command: " + command);
        };
    }

    /**
     * Feeds an animal at specified coordinates (row and column)
     * @param row row coordinate
     * @param column column coordinate
     * @return true if animal was fed successful, false otherwise.
     * @throws UnableToInteractException if unsuccessful execution - no animal to feed or if item
     * manager is not managing animals (plant farm).
     *
     * @requires itemManager is instance of an animal farm (AnimalFarmItemManager)
     * @requires row and colum are valid grid coordination within farm bounds.
     * @ensures animal "Fed" status is updated to true after successful execution.
     */
    private boolean feedAnimal(int row, int column) throws UnableToInteractException {
        // checking instance
        if (!(itemManager instanceof AnimalFarmItemManager)) {
            throw new UnableToInteractException("You cannot feed something that is not an animal!");
        }
        // cast itemManager to specific animal itemManager
        AnimalFarmItemManager animalManager = (AnimalFarmItemManager) itemManager;
        // use animal itemManager specific method on coordination
        boolean fed = animalManager.feed(row, column);
        // feeding unsuccessful
        if (!fed) {
            throw new UnableToInteractException("No animal found to feed at "
                    + "the specified location.");
        }
        // feeding successful
        return true;
    }

    /**
     * Removes an item from farm at specified coordinates (row and column).
     * @param row row coordinates
     * @param column column coordinates
     * @return true if item is successfully removed, false otherwise.
     *
     * @requires row and column are valid grid coordinates within farm bounds.
     * @ensures item is removed and position is reset to "ground".
     */
    private boolean removeItem(int row, int column) {
        itemManager.remove(row, column);
        return true; // remove successful
    }
}
