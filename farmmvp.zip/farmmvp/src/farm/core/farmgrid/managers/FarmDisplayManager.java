package farm.core.farmgrid.managers;

import java.util.List;

/**
 * Class responsible for displaying current state of the farm.
 * Class Invariant:
 * @invariant farm grid must always maintain correct number of rows and columns as initialised.
 * @invariant farmState must always represent a valid grid of items (plants, animals, ground).
 */
public class FarmDisplayManager {
    private final List<List<String>> farmState;
    private final int rows;
    private final int columns;

    /**
     * Constructor for FarmDisplayManager.
     * @param farmState a 2D list representing farm's state.
     * @param rows number of rows in farm.
     * @param columns number of columns in farm.
     *
     * @requires rows and columns greater than 0.
     * @requires farmState is not null.
     */
    public FarmDisplayManager(List<List<String>> farmState, int rows, int columns) {
        this.farmState = farmState;
        this.rows = rows;
        this.columns = columns;
    }

    /**
     * Generates and returns a string representation of farm grid, showing all items.
     * @return string of visual farm grid - there is a horizontal top and bottom fence, and
     * vertical fences at the start and end of each row.
     *
     * @ensures farm grid displays same number of rows and columns as farmState.
     * @ensures accurately reflects current state of farm, with symbols matching items.
     */
    public String farmDisplay() {
        String horizontalFence = "-".repeat((this.columns * 2) + 3);

        StringBuilder farmDisplay = new StringBuilder(horizontalFence + System.lineSeparator());
        // start each line with a "|" fence character
        // then display symbols with a space either side

        // note System.lineSeparator() is just \n but ensures it works
        // on all operating systems.

        for (int i = 0; i < this.rows; i++) {
            farmDisplay.append("| ");
            for (int j = 0; j < this.columns; j++) {
                int positionIndex = (i * this.columns) + j;
                farmDisplay.append(farmState.get(positionIndex).get(1)).append(" ");
            }
            farmDisplay.append("|").append(System.lineSeparator());
        }
        farmDisplay.append(horizontalFence).append(System.lineSeparator());
        return farmDisplay.toString();
    }
}
