package farm.core.farmgrid.managers.itemmanager;

import farm.core.UnableToInteractException;
import farm.core.farmgrid.managers.FarmItemManager;
import farm.inventory.product.*;
import farm.inventory.product.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * Class that manages any behaviour related to animals on the farm. This class is responsible for
 * managing the state of animals (e.g., cows, chickens, sheep) and their specific behaviour.
 *
 * @invariant animals can only be harvest once they have been fed, and only once a day
 */
public class AnimalFarmItemManager extends FarmItemManager {
    /**
     * Constructor for AnimalFarmItemManager
     * @param rows number of rows in grid.
     * @param columns number of columns in grid.
     *
     * @requires rows and columns greater than zero.
     * @ensures farm initialised with empty "ground" spots and correct grid size.
     */
    public AnimalFarmItemManager(int rows, int columns) {
        super(rows, columns, "animal");
    }



    /**
     * Places an animal on farm grid at specified coordinate.
     * @param row row coordinate
     * @param column column coordinate
     * @param symbol character representing item to be placed.
     * @return true if item successfully placed, false otherwise
     * @throws IllegalArgumentException if symbol does not represent a valid animal.
     * @throws IllegalStateException if position is already occupied
     *
     * @requires row >= 0 && column >= 0 && row < getRows() && column < getColumns()
     * @requires symbol represents a valid animal ('४', '৬', 'ඔ')
     * @ensures farm grid at the specified coordinate contains the new animal, and the position
     * is updated.
     */
    @Override
    public boolean place(int row, int column, char symbol)
            throws IllegalArgumentException, IllegalStateException {
        if (row < 0 || column < 0 || row >= this.getRows() || column >= this.getColumns()) {
            return false;
        }

        int positionIndex = (row * getColumns()) + column;
        String itemName = getItemNameFromSymbol(symbol); // getting animal name from symbol

        // valid animal check
        if (!isAnimal(itemName)) {
            throw new IllegalArgumentException("You cannot place that on an animal farm!");
        }

        // check is grid coordinate is already occupied
        if (!getFarmState().get(positionIndex).get(1).equals(" ")) {
            throw new IllegalStateException("Something is already there!");
        }

        // placing the new animal with fed, collected as false
        // array list - mutable
        List<String> newPositionInfo = new ArrayList<>(List.of(
                itemName, Character.toString(symbol), "Fed: false", "Collected: false"));
        getFarmState().set(positionIndex, newPositionInfo); // updating farm grid with new animal
        return true;
    }

    /**
     * Harvests animal at specified coordinate.
     * @param row row coordinate
     * @param column column coordinate
     * @return product harvested from the animal
     * @throws UnableToInteractException unsuccessful execution of harvest (animal has not been
     *                                      fed, has already been harvested, or location is invalid)
     *
     * @requires row >= 0 && column >= 0 && row < getRows() && column < getColumns()
     * @requires coordinate must contain a valid animal that has been fed.
     * @ensures animal is marked as "Collected" (true) after harvesting.
     */
    @Override
    public Product harvest(int row, int column) throws UnableToInteractException {
        // @requires: check if the position is within the valid grid range
        if (row < 0 || column < 0 || row >= this.getRows() || column >= this.getColumns()) {
            throw new UnableToInteractException("You can't harvest this location");
        }

        int positionIndex = row * getColumns() + column;
        List<String> position = getFarmState().get(positionIndex);

        // check if coordinate is empty ground
        if (position.get(0).equals("ground")) {
            throw new UnableToInteractException("You can't harvest an empty spot!");
        }

        // condition: animal must be fed
        if (position.get(2).equals("Fed: false")) {
            throw new UnableToInteractException("You have not fed this animal today!");
        }

        // condition: animal hasn't been harvested
        if (position.get(3).equals("Collected: true")) {
            throw new UnableToInteractException("This animal has produced an item already today!");
        }

        position = new ArrayList<>(position);  // create a mutable copy
        position.set(3, "Collected: true");  // mark animal as collected
        getFarmState().set(positionIndex, position);  // update farm state with new state

        // return corresponding product with random quality
        return switch (position.getFirst()) {
            case "cow" -> new Milk(getRandomQuality().getRandomQuality());
            case "chicken" -> new Egg(getRandomQuality().getRandomQuality());
            case "sheep" -> new Wool(getRandomQuality().getRandomQuality());
            default -> throw new UnableToInteractException("Invalid animal");
        };
    }

    /**
     * Ends current day, resetting "Fed" and "Collected" status of all animals on the farm.
     *
     * @ensures all animals on the farm have their "Fed" and "Collected" status set to false.
     */
    @Override
    public void endDay() {
        for (int i = 0; i < getFarmState().size(); i++) {
            List<String> itemInfo = getFarmState().get(i);
            // item is valid animal, resetting fed and collected status
            if (isAnimal(itemInfo.get(0))) {
                getFarmState().set(i, List.of(itemInfo.get(0), itemInfo.get(1), "Fed: false",
                        "Collected: " + "false"));
            }
        }
    }

    /**
     * Feeds an animal at specified coordinates, updating "Fed" status to true.
     * @param row row coordinate
     * @param column column coordinate
     * @return true if animal successfully fed, false otherwise.
     *
     * @requires row and column within farm bounds, and coordinate contains a valid animal.
     * @ensures "Fed" status of animal is updated to true.
     */
    public boolean feed(int row, int column) {
        int positionIndex = (row * getColumns()) + column;

        if (positionIndex >= getFarmState().size()) {
            return false; // out of farm bounds
        }

        List<String> positionInfo = getFarmState().get(positionIndex);
        // if valid animal, update "fed" status to tue
        if (isAnimal(positionInfo.get(0))) {
            getFarmState().set(positionIndex, List.of(
                    positionInfo.get(0), positionInfo.get(1), "Fed: true", positionInfo.get(3)));
            return true;
        }
        return false;
    }

    /**
     * Helper method to check if given item name represents a valid animal
     * @param itemName name of the item
     * @return true if item is an animal, false otherwise
     */
    private boolean isAnimal(String itemName) {
        return itemName.equals("cow") || itemName.equals("chicken") || itemName.equals("sheep");
    }

    /**
     * Helper methods that returns animal name corresponding to its symbol in farm grid.
     * @param symbol animal symbol
     * @return name of animal or "unknown" if symbol is not recognised.
     */
    private String getItemNameFromSymbol(char symbol) {
        return switch (symbol) {
            case '४' -> "cow";
            case '৬' -> "chicken";
            case 'ඔ' -> "sheep";
            default -> "unknown";
        };
    }

}
