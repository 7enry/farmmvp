package farm.core.farmgrid.managers;

import farm.core.UnableToInteractException;
import farm.inventory.product.Product;
import farm.inventory.product.data.RandomQuality;

import java.util.*;

/**
 * Abstract class for managing items on farm grid.
 * Manages the common methods for animal and plant items.
 * Class Invariants:
 * @invariant farm state is always reflects a valid grid of items.
 * @invariant each row and column index must remain within bounds specified.
 */
public abstract class FarmItemManager {
    private List<List<String>> farmState;
    private int rows;
    private int columns;
    private RandomQuality randomQuality;
    private String farmType;

    /**
     * Constructor for FarmItemManager.
     *
     * @param rows    number of rows in farm grid.
     * @param columns number of columns in farm grid.
     *
     * @requires rows and columns greater than 0.
     * @ensures initialisation of a farm grid with all coordinates set to "ground".
     */
    public FarmItemManager(int rows, int columns, String farmType) {
        this.rows = rows;
        this.columns = columns;
        this.randomQuality = new RandomQuality();
        this.farmState = initializeFarm(rows, columns);

        this.farmType = farmType;
    }

    /**
     * Getter for farmType
     * @return farmType
     */
    public String getFarmType() {
        return farmType;
    }

    /**
     * Initialises farm grid by setting all positions to "ground"
     *
     * @param rows    number of rows in farm grid.
     * @param columns number of columns in farm grid.
     * @return initialised farm grid
     * @ensures "ground" for all coordinates in farm grid.
     */
    private List<List<String>> initializeFarm(int rows, int columns) {
        List<List<String>> farm = new ArrayList<>();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                farm.add(new ArrayList<>(List.of("ground", " "))); // default: ground
            }
        }
        return farm;
    }

    /**
     * Places an item on farm at specified coordinates (row and column).
     * This method is handled by its item-specific subclasses for animal or plant.
     *
     * @param row    row coordinate
     * @param column column coordinate
     * @param symbol character representing item to be placed.
     * @return true if item was successfully placed, false otherwise.
     * @requires 0 <= row < rows && 0 <= column < columns
     * @ensures specified coordinate will contain item represented by symbol if successful
     */
    public abstract boolean place(int row, int column, char symbol);

    /**
     * Harvests item at specified coordinates (row and column).
     * This method is handled by its item-specific subclasses for animal or plant.
     *
     * @param row    row coordinate
     * @param column column coordinate
     * @return harvested product
     * @throws UnableToInteractException if item cannot be harvested (e.g. item not ready for
     *                                   harvest, or position is empty).
     * @requires 0 <= row < rows && 0 <= column < columns
     * @ensures item at the specified coordinates will either be harvested
     * or its state updated to reflect post-harvest conditions.
     */
    public abstract Product harvest(int row, int column) throws UnableToInteractException;

    /**
     * End's the farm day, updating the state of all items.
     * This method is handled by its item-specific subclasses for animal or plant.
     */
    public abstract void endDay();

    /**
     * Removes item at specified coordinate, replacing it with ground.
     *
     * @param row    row coordinate
     * @param column column coordinate
     * @throws IllegalArgumentException if row and column out of bounds
     * @ensures removed item will be replaced with ground.
     */
    public void remove(int row, int column) throws IllegalArgumentException {
        int positionIndex = (row * this.columns) + column;
        if (row < 0 || column < 0 || row >= this.rows || column >= this.columns) {
            throw new IllegalArgumentException("Invalid row or column.");
        }

        // replace the spot with empty ground
        List<String> spotOnGrid = List.of("ground", " ");
        farmState.set(positionIndex, spotOnGrid);
    }

    /*
    Getter methods primarily use in subclass of FarmItemManager due to encapsulation
     principles such that farmState, rows, columns, and randomQuality are private variables.
     */

    /**
     * Getter method for farmState
     *
     * @return farmState
     */
    public List<List<String>> getFarmState() {
        return farmState;
    }

    /**
     * Getter method for rows
     *
     * @return rows
     */
    public int getRows() {
        return rows;
    }

    /**
     * Getter method for columns
     *
     * @return columns
     */
    public int getColumns() {
        return columns;
    }

    /**
     * Getter method for randomQuality
     *
     * @return randomQuality
     */
    public RandomQuality getRandomQuality() {
        return randomQuality;
    }

    /**
     * Retrieves symbol
     * @param row row coordinate
     * @param col column coordinate
     * @return symbol character
     */
    public char getSymbolAt(int row, int col) {
        int positionIndex = (row * columns) + col;
        return farmState.get(positionIndex).get(1).charAt(0);
    }

}
