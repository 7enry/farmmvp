package farm.files;

import farm.core.farmgrid.FarmGrid;
import farm.core.farmgrid.Grid;

import java.io.*;
import java.util.List;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import farm.core.farmgrid.*;
import farm.core.farmgrid.managers.itemmanager.AnimalFarmItemManager;

/**
 * File Save Class
 */
public class FileSaver {
    /**
     * Constructor for the FileSaver class.
     */
    public FileSaver() {

    }


    /**
     * Saves the contents of the provided grid and farm type to a file with specified name.
     *
     * @param filename the file name to save.
     * @param grid     the grid instance to save to a file
     * @throws IOException if an I/O error occurs
     *
     * @ensures The grid's current state is saved to the specified file.
     * @invariant The state of the grid remains unchanged by the save operation.
     *
     * @example File save for 3x3 "plant" farm that is empty:
     * 3
     * 3
     * plant
     * ---------
     * |       |
     * |       |
     * |       |
     * ---------
     */
    public void save(String filename, Grid grid) throws IOException {
        if (!(grid instanceof FarmGrid)) {
            throw new IllegalArgumentException("Provided grid is not of type FarmGrid");
        }

        // Safely downcast grid to FarmGrid
        FarmGrid farmGrid = (FarmGrid) grid;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            // rows and columns
            writer.write(farmGrid.getRows() + "\n");
            writer.write(farmGrid.getColumns() + "\n");

            // farm type
            writer.write(farmGrid.getFarmType() + "\n");

            // farm state (using farm display method to generate the farm representation)
            writer.write(farmGrid.farmDisplay());
        }
    }
}
