package farm.files;

import farm.core.farmgrid.Grid;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import farm.core.farmgrid.FarmGrid;
import farm.core.UnableToInteractException;
import farm.core.farmgrid.Grid;

import java.io.IOException;

/**
 * File Load Class
 */
public class FileLoader {


    /**
     * Constructor for the FileLoader
     */
    public FileLoader() {
    }

    /**
     * Loads contents of the specified file into a Grid.
     *
     * @param filename the String filename to read contents from.
     * @return a grid instance.
     * @throws IOException if an I/O error occurs.
     *
     * @ensures The grid returned matches the state described in the file.
     * @invariant The grid dimensions and contents are consistent throughout the loading process.
     */

    public Grid load(String filename) throws IOException {
        BufferedReader fileReader = new BufferedReader(new FileReader(filename));
        String numRowsLine = fileReader.readLine(); // reading first line - num rows
        String numColsLine = fileReader.readLine(); // reading second line - num columns
        String farmType = fileReader.readLine(); // reading third line - farm type

        int numRows;
        int numCols;

        // catch
        try {
            numRows = Integer.parseInt(numRowsLine);
            numCols = Integer.parseInt(numColsLine);
        } catch (NumberFormatException e) {
            throw new IOException();
        }

        FarmGrid farmGrid = new FarmGrid(numRows, numCols, farmType);

        // top fence
        fileReader.readLine();
        for (int rowIndex = 0; rowIndex < numRows; rowIndex++) {
            fileReader.read();
            for (int colIndex = 0; colIndex < numCols; colIndex++) {
                for (int spaceIndex = 1; spaceIndex < 2; spaceIndex++) {
                    fileReader.read(); // skip spaces before symbol - "column" things
                }
                char itemSymbol = (char) fileReader.read();
                farmGrid.place(rowIndex, colIndex, itemSymbol);
            }
            // bottom fence
            fileReader.readLine();
        }
        return farmGrid;
    }
}





