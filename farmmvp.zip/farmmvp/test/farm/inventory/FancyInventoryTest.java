package farm.inventory;

import farm.core.InvalidStockRequestException;
import farm.core.FailedTransactionException;
import farm.inventory.FancyInventory;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import org.junit.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

public class FancyInventoryTest {

    private FancyInventory inventoryTest;
    private Barcode barcodeTest;
    private Quality qualityTest1;
    private Quality qualityTest2;

    @Before
    public void setUp() {
        inventoryTest = new FancyInventory();
        barcodeTest = Barcode.COFFEE;
        qualityTest1 = Quality.IRIDIUM;
        qualityTest2 = Quality.SILVER;
    }

    @Test
    public void testEmptyInventory() {
        // test: empty inventory should be empty when instantiated
        List<Product> productList = inventoryTest.getAllProducts();
        assertTrue("Inventory should be empty when instantiated", productList.isEmpty());
    }

    @Test
    public void testAddProduct() {
        // test: add single product to fancy inventory
        inventoryTest.addProduct(barcodeTest, qualityTest1);
        List<Product> productList = inventoryTest.getAllProducts();
        assertEquals("Fancy Inventory should contain 1 product", 1, productList.size());
        Product productAdded = productList.get(0);
        assertEquals("Product barcode should match added barcode", barcodeTest, productAdded.getBarcode());
        assertEquals("Product quality should match added quality", qualityTest1, productAdded.getQuality());
    }

    @Test
    public void testAddProductQuantity() throws InvalidStockRequestException {
        // test: add product with quantity to fancy inventory
        inventoryTest.addProduct(barcodeTest, qualityTest1, 8);
        List<Product> productList = inventoryTest.getAllProducts();
        assertEquals("Fancy Inventory should contain 8 products", 8, productList.size());
        for (Product product : productList) {
            assertEquals("Product barcode should match added barcode", barcodeTest, product.getBarcode());
            assertEquals("Product quality should match added quality", qualityTest1, product.getQuality());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddProductNegativeQuantity() throws InvalidStockRequestException {
        // test: add product with negative quantity should throw IllegalArgumentException
        inventoryTest.addProduct(barcodeTest, qualityTest1, -1);
    }

    @Test
    public void testAddProductZeroQuantity() {
        // test: add product with zero quantity should throw an exception
        try {
            inventoryTest.addProduct(barcodeTest, qualityTest1, 0);
        } catch (InvalidStockRequestException | IllegalArgumentException e) {
            // Expected exception
        }
        assertEquals("Inventory should remain empty after exception", 0, inventoryTest.getAllProducts().size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddNonExistentProduct() {
        // test: add non-existent product should throw IllegalArgumentException
        inventoryTest.addProduct(Barcode.valueOf("UNKNOWN"), qualityTest1);
    }

    @Test
    public void testAddProductOrder() throws InvalidStockRequestException {
        // test: add products in a specific order and verify the order in inventory
        inventoryTest.addProduct(barcodeTest, qualityTest2);
        inventoryTest.addProduct(barcodeTest, qualityTest1);
        List<Product> productList = inventoryTest.getAllProducts();
        assertEquals("First product should have SILVER quality", qualityTest2, productList.get(0).getQuality());
        assertEquals("Second product should have IRIDIUM quality", qualityTest1, productList.get(1).getQuality());
    }

    @Test
    public void testRemoveSingleProductHighestQuality() {
        // test: remove single product from fancy inventory (highest quality)
        inventoryTest.addProduct(barcodeTest, qualityTest1);
        inventoryTest.addProduct(barcodeTest, qualityTest2);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest);
        assertEquals("Should remove 1 product", 1, removedProducts.size());
        assertEquals("Removed product should have IRIDIUM quality", qualityTest1, removedProducts.get(0).getQuality());
    }

    @Test
    public void testRemoveSingleProductCheckOrder() {
        // test: remove single product and check the order of remaining products
        inventoryTest.addProduct(barcodeTest, qualityTest1);
        inventoryTest.addProduct(barcodeTest, qualityTest2);
        inventoryTest.removeProduct(barcodeTest);
        List<Product> remainingProducts = inventoryTest.getAllProducts();
        assertEquals("Remaining product should have SILVER quality", qualityTest2, remainingProducts.get(0).getQuality());
    }

    @Test
    public void testRemoveMoreThanAvailable() throws FailedTransactionException, InvalidStockRequestException {
        // test: remove more products than available (should remove what's available)
        inventoryTest.addProduct(barcodeTest, qualityTest1, 5);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest, 10);
        assertEquals("Should remove all available products", 5, removedProducts.size());
        assertFalse("Product should no longer exist in inventory", inventoryTest.existsProduct(barcodeTest));
    }

    @Test
    public void testRemoveNonExistentProduct() {
        // test: remove product that doesn't exist should return an empty list
        List<Product> removedProducts = inventoryTest.removeProduct(Barcode.WOOL);
        assertTrue("Should return an empty list for non-existent product", removedProducts.isEmpty());
    }

    @Test
    public void testGetAllProductsEmptyInventory() {
        // test: get all products when inventory is empty
        List<Product> productList = inventoryTest.getAllProducts();
        assertTrue("Inventory should be empty", productList.isEmpty());
    }

    @Test
    public void testGetAllProductsMultipleQualities() throws InvalidStockRequestException {
        // test: get all products after adding multiple products with different qualities
        inventoryTest.addProduct(barcodeTest, qualityTest1, 5);
        inventoryTest.addProduct(barcodeTest, qualityTest2, 3);
        List<Product> productList = inventoryTest.getAllProducts();
        assertEquals("Fancy Inventory should contain 8 products", 8, productList.size());
        assertEquals("First 5 products should have IRIDIUM quality", Collections.nCopies(5, qualityTest1),
                productList.subList(0, 5).stream().map(Product::getQuality).toList());
        assertEquals("Last 3 products should have SILVER quality", Collections.nCopies(3, qualityTest2),
                productList.subList(5, 8).stream().map(Product::getQuality).toList());
    }

    @Test
    public void testGetAllProductsInCorrectOrder() throws InvalidStockRequestException {
        // test: add products with different barcodes and verify order in inventory
        inventoryTest.addProduct(Barcode.WOOL, Quality.GOLD, 2);
        inventoryTest.addProduct(Barcode.EGG, Quality.SILVER, 1);
        inventoryTest.addProduct(Barcode.MILK, Quality.REGULAR, 3);
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("First product should be Egg", Barcode.EGG, products.get(0).getBarcode());
        assertEquals("Next product should be Milk", Barcode.MILK, products.get(1).getBarcode());
        assertEquals("Last product should be Wool", Barcode.WOOL, products.get(products.size() - 1).getBarcode());
    }

    @Test
    public void testGetStockedQuantity() throws InvalidStockRequestException {
        // test: get stocked quantity after adding products
        inventoryTest.addProduct(barcodeTest, qualityTest1, 8);
        assertEquals("Stocked quantity should match added quantity", 8, inventoryTest.getStockedQuantity(barcodeTest));
    }

    @Test
    public void testGetStockedQuantityNonExistentProduct() {
        // test: get stocked quantity of product that doesn't exist
        assertEquals("Stocked quantity should be 0 for non-existent product", 0, inventoryTest.getStockedQuantity(Barcode.WOOL));
    }

    @Test
    public void testExistsProduct() {
        // test: check if product exists in inventory after adding
        inventoryTest.addProduct(barcodeTest, qualityTest1);
        assertTrue("Product should exist in Fancy Inventory after being added", inventoryTest.existsProduct(barcodeTest));
    }

    @Test
    public void testExistsProductNonExistent() {
        // test: check if non-existent product exists in inventory
        assertFalse("Product should not exist in Fancy Inventory", inventoryTest.existsProduct(Barcode.WOOL));
    }

    @Test
    public void testInventoryAfterException() {
        // test: check inventory remains unchanged after an exception
        try {
            inventoryTest.addProduct(barcodeTest, qualityTest1, -1);
        } catch (InvalidStockRequestException | IllegalArgumentException e) {
            // Expected exception
        }
        assertEquals("Inventory should remain empty after exception", 0, inventoryTest.getAllProducts().size());
    }

    @Test
    public void testRemoveMultipleProductsHighestQuality() throws InvalidStockRequestException, FailedTransactionException {
        // test: remove multiple products and ensure highest quality is removed first
        inventoryTest.addProduct(barcodeTest, qualityTest2, 3);
        inventoryTest.addProduct(barcodeTest, qualityTest1, 5);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest, 4);
        assertEquals("Should remove 4 products", 4, removedProducts.size());
        assertEquals("First product removed should have IRIDIUM quality", qualityTest1, removedProducts.get(0).getQuality());
        assertEquals("Last product removed should have IRIDIUM quality", qualityTest1, removedProducts.get(3).getQuality());
    }

    @Test
    public void testGetAllProductsDifferentBarcodes() throws InvalidStockRequestException {
        // test: get all products with different barcodes and verify order by barcode value
        inventoryTest.addProduct(Barcode.EGG, qualityTest1, 2);
        inventoryTest.addProduct(Barcode.WOOL, qualityTest2, 1);
        inventoryTest.addProduct(Barcode.MILK, qualityTest1, 3);
        List<Product> productList = inventoryTest.getAllProducts();
        assertEquals("Fancy Inventory should contain 6 products", 6, productList.size());
        assertEquals("First 2 products should be Eggs", Barcode.EGG, productList.get(0).getBarcode());
        assertEquals("Last product should be Wool", Barcode.WOOL, productList.get(5).getBarcode());
    }

    @Test
    public void testRemoveProductAndCheckQuantity() throws InvalidStockRequestException {
        // test: remove product and check if quantity is updated correctly
        inventoryTest.addProduct(barcodeTest, qualityTest1, 5);
        inventoryTest.removeProduct(barcodeTest);
        assertEquals("Stocked quantity should be 4 after removing one product", 4, inventoryTest.getStockedQuantity(barcodeTest));
    }

    @Test
    public void testRemoveAllProducts() throws InvalidStockRequestException, FailedTransactionException {
        // test: remove all products and ensure inventory is empty
        inventoryTest.addProduct(barcodeTest, qualityTest1, 5);
        inventoryTest.removeProduct(barcodeTest, 5);
        assertTrue("Inventory should be empty after removing all products", inventoryTest.getAllProducts().isEmpty());
    }

    @Test
    public void testRemoveMoreThanMaxQuantity() throws InvalidStockRequestException, FailedTransactionException {
        // test: remove more than maximum quantity available
        inventoryTest.addProduct(barcodeTest, qualityTest1, 100);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest, 150);
        assertEquals("Should remove all available products", 100, removedProducts.size());
        assertFalse("Product should no longer exist in inventory", inventoryTest.existsProduct(barcodeTest));
    }

    @Test
    public void testAddMultipleBarcodesAndCheckRemovalOrder() throws InvalidStockRequestException, FailedTransactionException {
        // test: add multiple barcodes and check removal order by barcode priority
        inventoryTest.addProduct(Barcode.MILK, qualityTest1, 5);
        inventoryTest.addProduct(Barcode.WOOL, qualityTest2, 3);
        inventoryTest.addProduct(Barcode.EGG, qualityTest1, 4);
        List<Product> removedProducts = inventoryTest.removeProduct(Barcode.WOOL, 2);
        assertEquals("Should remove 2 Wool products", 2, removedProducts.size());
        assertEquals("Removed products should have barcode WOOL", Barcode.WOOL, removedProducts.get(0).getBarcode());
    }

    @Test
    public void testAddMultipleBarcodesAndCheckAllProductsOrder() throws InvalidStockRequestException {
        // test: add multiple barcodes and check getAllProducts order
        inventoryTest.addProduct(Barcode.MILK, qualityTest1, 2);
        inventoryTest.addProduct(Barcode.WOOL, qualityTest2, 1);
        inventoryTest.addProduct(Barcode.EGG, qualityTest1, 3);
        List<Product> productList = inventoryTest.getAllProducts();
        assertEquals("Fancy Inventory should contain 6 products", 6, productList.size());
        assertEquals("First 3 products should be Eggs", Barcode.EGG, productList.get(0).getBarcode());
        assertEquals("Next 2 products should be Milk", Barcode.MILK, productList.get(3).getBarcode());
        assertEquals("Last product should be Wool", Barcode.WOOL, productList.get(5).getBarcode());
    }

    @Test
    public void testCorrectBarcodeCreation() {
        // test: ensure products are created with correct barcodes
        Barcode[] barcodes = Barcode.values();
        Quality[] qualities = Quality.values();

        for (Barcode barcode : barcodes) {
            for (Quality quality : qualities) {
                inventoryTest.addProduct(barcode, quality);
                Product product = inventoryTest.getAllProducts().get(0);

                assertEquals("Product should have the correct barcode", barcode, product.getBarcode());
                inventoryTest.removeProduct(barcode);
            }
        }
    }

    @Test
    public void testRemoveHighestQualityProduct() {
        // test: remove the highest quality product from inventory
        inventoryTest.addProduct(barcodeTest, Quality.SILVER);
        inventoryTest.addProduct(barcodeTest, Quality.GOLD);
        inventoryTest.addProduct(barcodeTest, Quality.REGULAR);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest);
        assertEquals("Should remove the highest quality product first", Quality.GOLD, removedProducts.get(0).getQuality());
    }

    @Test
    public void testProductIsRemovedAfterRemoval() {
        // test: check if product is removed after removal operation
        inventoryTest.addProduct(barcodeTest, qualityTest1);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest);
        assertFalse("Product should no longer exist in inventory after removal", inventoryTest.existsProduct(barcodeTest));
        assertEquals("Removed product should match added product", qualityTest1, removedProducts.get(0).getQuality());
    }

    @Test
    public void testRemoveNonExistingProduct() {
        // test: removing non-existing product should return an empty list
        List<Product> removedProducts = inventoryTest.removeProduct(Barcode.WOOL);
        assertTrue("Removing non-existing product should return an empty list", removedProducts.isEmpty());
    }

    @Test
    public void testEnsureHighestQualityIsRemoved() {
        // test: ensure highest quality product is removed when removing
        inventoryTest.addProduct(barcodeTest, Quality.REGULAR);
        inventoryTest.addProduct(barcodeTest, Quality.GOLD);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest);
        assertEquals("Should remove the highest quality product", Quality.GOLD, removedProducts.get(0).getQuality());
    }
}
