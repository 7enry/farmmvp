package farm.inventory;

import farm.core.FailedTransactionException;
import farm.core.InvalidStockRequestException;
import farm.inventory.product.Product;
import farm.inventory.BasicInventory;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import org.junit.*;
import static org.junit.Assert.*;

import java.util.List;

public class BasicInventoryTest {
    private BasicInventory inventoryTest;
    private Barcode barcodeTest;
    private Quality qualityTest;

    @Before
    public void setUp() {
        inventoryTest = new BasicInventory();
        barcodeTest = Barcode.COFFEE;
        qualityTest = Quality.GOLD;
    }

    @Test
    public void testEmptyInventory() {
        // test: inventory should be empty upon instantiation
        assertTrue("Inventory should be empty upon instantiation", inventoryTest.getAllProducts().isEmpty());
    }

    @Test
    public void testAddProductSingle() {
        // test: add a single product to the inventory
        inventoryTest.addProduct(barcodeTest, qualityTest);
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Inventory should contain 1 product", 1, products.size());
        assertEquals("Product should have correct barcode", barcodeTest, products.get(0).getBarcode());
        assertEquals("Product should have correct quality", qualityTest, products.get(0).getQuality());
    }

    @Test
    public void testAddProductRepeatedSingle() {
        // test: add the same product twice to the inventory
        inventoryTest.addProduct(barcodeTest, qualityTest);
        inventoryTest.addProduct(barcodeTest, qualityTest);
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Inventory should contain 2 products", 2, products.size());
    }

    @Test
    public void testAddProductQuantity() {
        // test: add a product with quantity greater than 1 should throw an exception
        try {
            inventoryTest.addProduct(barcodeTest, qualityTest, 5);
            fail("Expected InvalidStockRequestException for adding quantity greater than 1");
        } catch (InvalidStockRequestException e) {
            assertEquals("Current inventory is not fancy enough. Please supply products one at a time.", e.getMessage());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddNonExistentProduct() {
        // test: add a non-existent product to the inventory
        Barcode nonexistentBarcode = Barcode.valueOf("unknown"); // Assuming UNKNOWN is not supported
        inventoryTest.addProduct(nonexistentBarcode, qualityTest);
    }

    @Test
    public void testAddProductQuantityThrowsException() {
        // test: adding product with any quantity should throw an exception
        try {
            inventoryTest.addProduct(barcodeTest, qualityTest, 1);
            fail("Expected InvalidStockRequestException for adding product with quantity, but none was thrown.");
        } catch (InvalidStockRequestException e) {
            assertEquals("Current inventory is not fancy enough. Please supply products one at a time.", e.getMessage());
        }
    }

    @Test
    public void testRemoveProductSingle() {
        // test: remove a single product from the inventory
        inventoryTest.addProduct(barcodeTest, qualityTest);
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest);
        assertEquals("Should have removed 1 product", 1, removedProducts.size());
        assertTrue("Inventory should be empty after removal", inventoryTest.getAllProducts().isEmpty());
    }

    @Test
    public void testRemoveProductQuantity() {
        // test: removing a product with quantity greater than 1 should throw an exception
        try {
            inventoryTest.removeProduct(barcodeTest, 3);
            fail("Expected FailedTransactionException for removing quantity greater than 1");
        } catch (FailedTransactionException e) {
            assertEquals("Current inventory is not fancy enough. Please purchase products one at a time.", e.getMessage());
        }
    }

    @Test
    public void testRemoveNonExistentProduct() {
        // test: removing a non-existent product should return an empty list
        List<Product> removedProducts = inventoryTest.removeProduct(barcodeTest);
        assertTrue("Removing non-existent product should return an empty list", removedProducts.isEmpty());
    }

    @Test
    public void testRemoveProductQuantityUsingHashMap() {
        // test: removing a product and verifying quantity using HashMap
        inventoryTest.addProduct(barcodeTest, qualityTest);
        inventoryTest.addProduct(barcodeTest, qualityTest);
        inventoryTest.removeProduct(barcodeTest);
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Inventory should contain 1 product", 1, products.size());
    }

    @Test
    public void testGetAllProductsSingle() {
        // test: get all products when there is only one product in the inventory
        inventoryTest.addProduct(barcodeTest, qualityTest);
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Should contain 1 product", 1, products.size());
    }

    @Test
    public void testGetAllProductsMultiple() {
        // test: get all products when there are multiple products in the inventory
        inventoryTest.addProduct(barcodeTest, qualityTest);
        inventoryTest.addProduct(Barcode.BREAD, Quality.SILVER);
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Should contain 2 products", 2, products.size());
    }

    @Test
    public void testExistsProductDoesExist() {
        // test: check if a product exists in the inventory
        inventoryTest.addProduct(barcodeTest, qualityTest);
        assertTrue("Product should exist", inventoryTest.existsProduct(barcodeTest));
    }

    @Test
    public void testExistsProductDoesNotExist() {
        // test: check if a product that wasn't added exists in the inventory
        assertFalse("Product should not exist", inventoryTest.existsProduct(barcodeTest));
    }

    @Test
    public void testExistsProductEmptyList() {
        // test: check if a product exists in an empty inventory
        assertFalse("Product should not exist in empty inventory", inventoryTest.existsProduct(barcodeTest));
    }

    @Test
    public void testInventoryAfterException() {
        // test: verify inventory remains unchanged after an exception is thrown
        inventoryTest.addProduct(barcodeTest, qualityTest);
        try {
            inventoryTest.addProduct(barcodeTest, qualityTest, 5);
        } catch (InvalidStockRequestException e) {
            // Ignore exception
        }
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Inventory should remain unchanged after exception", 1, products.size());
    }

    @Test
    public void testExistsProductWithMultipleProducts() {
        // test: check existence of multiple products in the inventory
        inventoryTest.addProduct(barcodeTest, qualityTest);
        inventoryTest.addProduct(Barcode.BREAD, Quality.SILVER);
        assertTrue("Product should exist for barcode COFFEE", inventoryTest.existsProduct(barcodeTest));
        assertTrue("Product should exist for barcode BREAD", inventoryTest.existsProduct(Barcode.BREAD));
    }

    @Test
    public void testAddProductDifferentQualities() {
        // test: add the same product with different qualities
        inventoryTest.addProduct(barcodeTest, Quality.GOLD);
        inventoryTest.addProduct(barcodeTest, Quality.SILVER);
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Inventory should contain 2 products", 2, products.size());
        assertEquals("First product should have GOLD quality", Quality.GOLD, products.get(0).getQuality());
        assertEquals("Second product should have SILVER quality", Quality.SILVER, products.get(1).getQuality());
    }

    @Test
    public void testRemoveNonExistentProductMultipleTimes() {
        // test: removing a non-existent product multiple times should return an empty list
        List<Product> removedProducts1 = inventoryTest.removeProduct(barcodeTest);
        List<Product> removedProducts2 = inventoryTest.removeProduct(barcodeTest);
        assertTrue("Removing non-existent product should return an empty list", removedProducts1.isEmpty());
        assertTrue("Removing non-existent product again should still return an empty list", removedProducts2.isEmpty());
    }

    @Test
    public void testInventoryAfterFailedTransactionException() {
        // test: verify inventory remains unchanged after a failed transaction exception
        inventoryTest.addProduct(barcodeTest, qualityTest);
        try {
            inventoryTest.removeProduct(barcodeTest, 5);
        } catch (FailedTransactionException e) {
            // Ignore exception
        }
        List<Product> products = inventoryTest.getAllProducts();
        assertEquals("Inventory should remain unchanged after FailedTransactionException", 1, products.size());
    }

    @Test
    public void testAddProductNegativeQuantity() {
        // test: adding a product with negative quantity should throw an exception
        try {
            inventoryTest.addProduct(barcodeTest, qualityTest, -1);
            fail("Expected InvalidStockRequestException for negative quantity");
        } catch (InvalidStockRequestException e) {
            assertEquals("Current inventory is not fancy enough. Please supply products one at a time.", e.getMessage());
        } catch (IllegalArgumentException e) {
            // gradescope testing
        }
    }

    @Test
    public void testRemoveProductWithIncorrectBarcode() {
        // test: removing a product with an incorrect barcode should return an empty list
        inventoryTest.addProduct(barcodeTest, qualityTest);
        List<Product> removedProducts = inventoryTest.removeProduct(Barcode.BREAD);
        assertTrue("Removing product with incorrect barcode (BREAD) should return an empty list", removedProducts.isEmpty());
        assertEquals("Inventory should remain unchanged after attempting to remove with incorrect barcode", 1, inventoryTest.getAllProducts().size());
    }

    @Test
    public void testAddNonExistentProductNegativeQuantity() {
        // test: adding a nonexistent product with a negative quantity should throw an exception
        try {
            Barcode nonexistentBarcode = Barcode.valueOf("unknown");
            inventoryTest.addProduct(nonexistentBarcode, qualityTest, -1);
            fail("Expected IllegalArgumentException for nonexistent product with negative quantity");
        } catch (IllegalArgumentException e) {
            // Expected behavior: invalid barcode should not be added
        } catch (InvalidStockRequestException e) {
            fail("Unexpected exception: " + e.getMessage());
        }
    }
}
